package org.example;

import com.sendgrid.*;
import com.sendgrid.helpers.mail.Mail;
import com.sendgrid.helpers.mail.objects.Content;
import com.sendgrid.helpers.mail.objects.Email;
import java.io.IOException;
import java.util.Random;

public class SendEmail {
    public static void sendEmail(String userEmail,int seats,Projection projection) {
        // SendGrid API key
        String apiKey = "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";

        Email from = new Email("vixa1914@gmail.com");
        String subject = "Rezervacija karata [SendGrid]";
        Email to = new Email(userEmail);
        Content content = new Content("text/plain", "Rezervisali ste "+seats+" mesta.\n "
                +"Informacije o projekciji: "+projection.toString()+"\n"
                +generateCodes(seats));
        Mail mail = new Mail(from, subject, to, content);

        SendGrid sg = new SendGrid(apiKey);
        Request request = new Request();

        try {
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    public static String generateCodes(int seats){
        String generated="";
        Random random = new Random();
        for(int i=0;i<seats;i++){
            int sequence=i+1;
            generated+="Karta "+ sequence+": "+ random.nextInt(90000)+"\n";
        }
        return generated;
    }
}
