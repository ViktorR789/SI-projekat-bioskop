package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.List;

public class Employee {
    database conn=new database();

    private int employeeId;
    private String username;
    private String password;

    private JFrame employeeFrame = new JFrame();
    private CardLayout cardLayout = new CardLayout();
    private JPanel panelContainer = new JPanel(cardLayout);
    private JPanel moviesPanel = new JPanel();


    public Employee(int userId, String username, String password) {
        this.employeeId = userId;
        this.username = username;
        this.password = password;
        JPanel settingsPanel = new JPanel();
        JPanel menuPanel = new JPanel();
        JPanel welcomePanel = new JPanel();
        JPanel newMoviePanel=new JPanel();
        JPanel newProjectionPanel=new JPanel();
        JPanel privilegesPanel=new JPanel();

        welcomePanel.setLayout(new BorderLayout());
        JLabel welcomeLabel = new JLabel();
        welcomeLabel.setHorizontalAlignment(JLabel.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomeLabel.setText("Dobrodosli "+ this.username);
        welcomePanel.add(welcomeLabel, BorderLayout.CENTER);

        JLabel usernameM=new JLabel();
        JButton moviesButton = new JButton("Filmovi");
        JButton settingsButton = new JButton("Podesavanja");
        JButton addMovieButton= new JButton("Dodajte novi film");
        JButton addProjectionButton=new JButton("Dodajte novu projekciju");
        JButton buttonForPrivileges=new JButton("Dodavanje privilegija");
        JButton logoutButton = new JButton("Odjava");
        menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));
        menuPanel.setPreferredSize(new Dimension(200, employeeFrame.getHeight()));
        usernameM.setAlignmentX(Component.CENTER_ALIGNMENT);
        moviesButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        settingsButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        addMovieButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        addProjectionButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonForPrivileges.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoutButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        usernameM.setPreferredSize(new Dimension(180, 50));
        moviesButton.setPreferredSize(new Dimension(180, 20));
        settingsButton.setPreferredSize(new Dimension(180, 20));
        addMovieButton.setPreferredSize(new Dimension(180,20));
        addProjectionButton.setPreferredSize(new Dimension(180,20));
        buttonForPrivileges.setPreferredSize(new Dimension(180,20));
        logoutButton.setPreferredSize(new Dimension(180, 20));

        moviesButton.setFocusable(false);
        settingsButton.setFocusable(false);
        addMovieButton.setFocusable(false);
        addProjectionButton.setFocusable(false);
        buttonForPrivileges.setFocusable(false);
        logoutButton.addActionListener(e -> logout());

        menuPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        menuPanel.add(usernameM);
        menuPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        menuPanel.add(moviesButton);
        moviesButton.addActionListener(e->{
            cardLayout.show(panelContainer, "Movies");
        });
        menuPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        menuPanel.add(settingsButton);
        settingsButton.addActionListener(e->{
            cardLayout.show(panelContainer, "Settings");
        });
        menuPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        menuPanel.add(addMovieButton);
        addMovieButton.addActionListener(e->{
            cardLayout.show(panelContainer,"NewMovie");
        });
        menuPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        menuPanel.add(addProjectionButton);
        addProjectionButton.addActionListener(e->{
            cardLayout.show(panelContainer,"NewProjection");
        });
        menuPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        menuPanel.add(buttonForPrivileges);
        buttonForPrivileges.addActionListener(e->{
            cardLayout.show(panelContainer,"Privileges");
        });
        menuPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        menuPanel.add(logoutButton);


        setupMoviesPanel();
        setupSettingsPanel(settingsPanel);
        setupNewMoviePanel(newMoviePanel);
        setupNewProjectionPanel(newProjectionPanel);
        setupPrivilegesPanel(privilegesPanel);


        panelContainer.add(welcomePanel, "Welcome");
        panelContainer.add(moviesPanel, "Movies");
        panelContainer.add(settingsPanel, "Settings");
        panelContainer.add(newMoviePanel,"NewMovie");
        panelContainer.add(newProjectionPanel,"NewProjection");
        panelContainer.add(privilegesPanel,"Privileges");


        employeeFrame.setLayout(new BorderLayout());
        employeeFrame.add(menuPanel, BorderLayout.WEST);
        employeeFrame.add(panelContainer, BorderLayout.CENTER);
        employeeFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        employeeFrame.setSize(700, 500);
        employeeFrame.setLocationRelativeTo(null);
        employeeFrame.setVisible(true);


        cardLayout.show(panelContainer, "Welcome");
    }

    private void logout() {
        this.password=null;
        this.username=null;
        employeeFrame.dispose();
    }


    public void setupMoviesPanel() {
        moviesPanel.setLayout(new BorderLayout());
        List<String> movies = conn.getAllMovies();
        JLabel movieLabel = new JLabel("Filmovi:");
        movieLabel.setHorizontalAlignment(JLabel.CENTER);
        movieLabel.setFont(new Font("Arial", Font.BOLD, 24));
        moviesPanel.add(movieLabel, BorderLayout.NORTH);
        JPanel movieListPanel = new JPanel();
        movieListPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        for (String movie : movies) {
            JPanel moviePanel = new JPanel();
            moviePanel.setLayout(new BorderLayout());
            JLabel movieNameLabel = new JLabel(movie);
            movieNameLabel.setFont(new Font("Arial", Font.PLAIN, 18));
            JButton deleteMovieButton = new JButton("Obrisite film");
            deleteMovieButton.setFocusable(false);
            int movieId=conn.getMovieIdByTitle(movie);
            deleteMovieButton.addActionListener(e -> {
                deleteReservationForMovie(movieId);
                deleteProjectionsForMovie(movieId);
                deleteMovie(movie);
            });
            moviePanel.add(movieNameLabel, BorderLayout.WEST);
            moviePanel.add(deleteMovieButton, BorderLayout.EAST);
            moviePanel.setPreferredSize(new Dimension(500, 50));
            gbc.gridy++;
            gbc.anchor = GridBagConstraints.NORTHEAST;
            movieListPanel.add(moviePanel, gbc);
            gbc.gridy++;
            gbc.insets = new Insets(5, 0, 5, 0);
            movieListPanel.add(Box.createRigidArea(new Dimension(0, 10)), gbc);
        }
        JScrollPane scrollPane = new JScrollPane(movieListPanel);
        moviesPanel.add(scrollPane, BorderLayout.CENTER);
    }


    private void deleteMovie(String movie) {
        conn.deleteMovie(movie);
        refreshMoviePanel();
    }

    private void deleteProjectionsForMovie(int movieId) {
        conn.deleteProjectionsForMovie(movieId);
        refreshMoviePanel();
    }

    private void deleteReservationForMovie(int movieId) {
        conn.deleteReservationForMovie(movieId);
        refreshMoviePanel();
    }

    private void refreshMoviePanel() {
        moviesPanel.removeAll();
        setupMoviesPanel();
        moviesPanel.revalidate();
        moviesPanel.repaint();
    }

    public void setupSettingsPanel(JPanel settingsPanel){
        JLabel newUsernameLabel=new JLabel("Novo korisnicko ime:");
        JLabel newPasswordLabel=new JLabel("Nova lozika: ");
        JLabel newPasswordAgainLabel=new JLabel("Ponovite novu lozinku: ");
        JTextField newUsernameField=new JTextField();
        JPasswordField newPasswordField=new JPasswordField();
        JPasswordField newPasswordFieldAgain=new JPasswordField();
        JButton updateButton=new JButton("Promeni");
        updateButton.addActionListener(e->{
            String newUsername=newUsernameField.getText();
            String newPassword=newPasswordField.getText();
            String newPasswordAgain=newPasswordFieldAgain.getText();
            if(newPasswordAgain.equals(newPasswordAgain)){
                conn.updateUser(this.username,this.password,newUsername,newPassword);
                newUsernameField.setText("");
                newPasswordField.setText("");
                newPasswordFieldAgain.setText("");
            }
        });
        settingsPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel settingsLabel = new JLabel();
        settingsLabel.setHorizontalAlignment(JLabel.CENTER);
        settingsLabel.setFont(new Font("Arial", Font.BOLD, 24));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        settingsPanel.add(settingsLabel, gbc);

        gbc.anchor = GridBagConstraints.WEST;
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        settingsPanel.add(newUsernameLabel, gbc);
        gbc.gridx = 1;
        settingsPanel.add(newUsernameField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        settingsPanel.add(newPasswordLabel, gbc);
        gbc.gridx = 1;
        settingsPanel.add(newPasswordField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 3;
        settingsPanel.add(newPasswordAgainLabel, gbc);
        gbc.gridx = 1;
        settingsPanel.add(newPasswordFieldAgain, gbc);
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.CENTER;
        settingsPanel.add(updateButton, gbc);
    }

    public void setupNewMoviePanel(JPanel newMoviePanel) {
        newMoviePanel.setLayout(new BorderLayout());
        JLabel titleLabel = new JLabel("Unesite naziv filma:");
        titleLabel.setHorizontalAlignment(JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        newMoviePanel.add(titleLabel, BorderLayout.NORTH);
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.NORTH;
        gbc.insets = new Insets(20, 10, 10, 10);
        JLabel nameLabel = new JLabel("Naziv filma:");
        inputPanel.add(nameLabel, gbc);
        gbc.gridx++;
        JTextField nameField = new JTextField(20);
        inputPanel.add(nameField, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel durationLabel = new JLabel("Trajanje filma (min):");
        inputPanel.add(durationLabel, gbc);
        gbc.gridx++;
        JTextField durationField = new JTextField(20);
        inputPanel.add(durationField, gbc);
        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Dodajte novi film");
        addButton.addActionListener(e -> {
            String movieName = nameField.getText().trim();
            String durationText = durationField.getText().trim();
            if (movieName.isEmpty() || durationText.isEmpty()) {
                JOptionPane.showMessageDialog(employeeFrame, "Molimo unesite naziv i trajanje filma.", "Greska", JOptionPane.ERROR_MESSAGE);
                return;
            }
            int movieDuration;
            try {
                movieDuration = Integer.parseInt(durationText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(employeeFrame, "Molimo unesite validno trajanje filma u minutama.", "Greska", JOptionPane.ERROR_MESSAGE);
                return;
            }
            conn.addNewMovie(movieName, movieDuration);
            refreshMoviePanel();
            JOptionPane.showMessageDialog(employeeFrame, "Novi film uspesno dodat.", "Film dodat", JOptionPane.INFORMATION_MESSAGE);
            nameField.setText("");
            durationField.setText("");
        });
        buttonPanel.add(addButton);
        newMoviePanel.add(inputPanel, BorderLayout.CENTER);
        newMoviePanel.add(buttonPanel, BorderLayout.SOUTH);
    }

    public void setupNewProjectionPanel(JPanel newProjectionPanel) {
        int numberOfHalls=conn.getNumOfHalls();
        newProjectionPanel.setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("Dodajte novu projekciju:");
        titleLabel.setHorizontalAlignment(JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        newProjectionPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(20, 10, 10, 10);

        JLabel hallIdLabel = new JLabel("Broj sale:");
        inputPanel.add(hallIdLabel, gbc);
        gbc.gridx++;
        JTextField hallIdField = new JTextField(20);
        inputPanel.add(hallIdField, gbc);
        JLabel movieTitleLabel = new JLabel("Naziv filma:");
        gbc.gridx = 0;
        gbc.gridy++;
        inputPanel.add(movieTitleLabel, gbc);
        gbc.gridx++;
        JTextField movieTitleField = new JTextField(20);
        inputPanel.add(movieTitleField, gbc);
        JLabel freeSeatsLabel = new JLabel("Slobodna mesta:");
        gbc.gridx = 0;
        gbc.gridy++;
        inputPanel.add(freeSeatsLabel, gbc);
        gbc.gridx++;
        JTextField freeSeatsField = new JTextField(20);
        inputPanel.add(freeSeatsField, gbc);
        JLabel timeSlotLabel = new JLabel("Termin (hh:mm:ss):");
        gbc.gridx = 0;
        gbc.gridy++;
        inputPanel.add(timeSlotLabel, gbc);
        gbc.gridx++;
        JTextField timeSlotField = new JTextField(20);
        inputPanel.add(timeSlotField, gbc);
        JLabel dateLabel = new JLabel("Datum (gggg-mm-dd):");
        gbc.gridx = 0;
        gbc.gridy++;
        inputPanel.add(dateLabel, gbc);
        gbc.gridx++;
        JTextField dateField = new JTextField(20);
        inputPanel.add(dateField, gbc);

        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Dodajte projekciju");
        addButton.addActionListener(e -> {
            try {
                int hallId = Integer.parseInt(hallIdField.getText().trim());
                if(hallId>numberOfHalls){
                    JOptionPane.showMessageDialog(employeeFrame, "Uneli ste nepostojaci broj sale.(Broj sala je: "+numberOfHalls+")", "Greska", JOptionPane.ERROR_MESSAGE);
                }
                else {
                    String movieTitle = movieTitleField.getText();
                    int movieExists=conn.movieExists(movieTitle);
                    if(movieExists==0){
                        JOptionPane.showMessageDialog(employeeFrame, "Ne postoji film u bazi.", "Greska", JOptionPane.ERROR_MESSAGE);
                    }
                    else {
                        int freeSeats = Integer.parseInt(freeSeatsField.getText().trim());
                        int numberOfSeatsOfHall=conn.getNumberOfSeatsOfHall(hallId);
                        if(freeSeats>numberOfSeatsOfHall){
                            JOptionPane.showMessageDialog(employeeFrame, "Prekoracen je kapacitet sale.("+numberOfSeatsOfHall+")", "Greska", JOptionPane.ERROR_MESSAGE);
                        }
                        else{
                            String timeSlot = timeSlotField.getText().trim();
                            LocalDate date = LocalDate.parse(dateField.getText().trim());
                            LocalTime start = LocalTime.parse(timeSlot);
                            LocalDate currentDate=LocalDate.now();
                            LocalTime currentTime=LocalTime.now();
                            if(date.isBefore(currentDate) || (date.isEqual(currentDate) && start.isBefore(currentTime))){
                                JOptionPane.showMessageDialog(employeeFrame, "Projekcija se ne moze zakazati u proslosti.", "Projekcija dodata", JOptionPane.INFORMATION_MESSAGE);
                            }
                            else {
                                int movieId = conn.getMovieIdByTitle(movieTitle);
                                conn.addNewProjection(hallId, movieId, freeSeats, start, date);

                                JOptionPane.showMessageDialog(employeeFrame, "Nova projekcija uspesno dodata.", "Projekcija dodata", JOptionPane.INFORMATION_MESSAGE);
                                hallIdField.setText("");
                                movieTitleField.setText("");
                                freeSeatsField.setText("");
                                timeSlotField.setText("");
                                dateField.setText("");
                            }
                        }
                    }
                }
            } catch (NumberFormatException | DateTimeParseException ex) {
                JOptionPane.showMessageDialog(employeeFrame, "Unesite validne vrednosti za sva polja.", "Greska", JOptionPane.ERROR_MESSAGE);
            }
        });

        buttonPanel.add(addButton);

        newProjectionPanel.add(inputPanel, BorderLayout.CENTER);
        newProjectionPanel.add(buttonPanel, BorderLayout.SOUTH);
    }
    public void setupPrivilegesPanel(JPanel privilegesPanel){
        privilegesPanel.setLayout(new BorderLayout());
        List<User> users=conn.listUsersWithoutPrivileges();
        JLabel privilegesLabel = new JLabel("Privilegije");
        privilegesLabel.setHorizontalAlignment(JLabel.CENTER);
        privilegesLabel.setFont(new Font("Arial", Font.BOLD, 24));
        privilegesPanel.add(privilegesLabel, BorderLayout.NORTH);
        JPanel privilegesListPanel = new JPanel();
        privilegesListPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        for (User user : users) {
            JPanel singleUserPanel = new JPanel();
            singleUserPanel.setLayout(new BorderLayout());
            JLabel userNameLabel = new JLabel(user.getUserId()+" "+user.getUsername()+" ");
            userNameLabel.setFont(new Font("Arial", Font.PLAIN, 18));
            userNameLabel.setPreferredSize(new Dimension(400, 50));
            JButton addPrivilegeButton = new JButton("Privilegija");
            addPrivilegeButton.setFocusable(false);
            addPrivilegeButton.setPreferredSize(new Dimension(150, 50));
            addPrivilegeButton.addActionListener(e -> addPrivilege(user,privilegesPanel));
            singleUserPanel.add(userNameLabel, BorderLayout.WEST);
            singleUserPanel.add(addPrivilegeButton, BorderLayout.EAST);
            singleUserPanel.setPreferredSize(new Dimension(500, 50));
            privilegesListPanel.add(singleUserPanel, gbc);
            gbc.gridy++;
            gbc.insets = new Insets(10, 0, 10, 0);
        }
        JScrollPane scrollPane = new JScrollPane(privilegesListPanel);
        privilegesPanel.add(scrollPane, BorderLayout.CENTER);
    }

    public void addPrivilege(User user,JPanel privilegesPanel){
        int userId=user.getUserId();
        conn.addPrivilegesToUser(userId);
        privilegesPanel.removeAll();
        setupPrivilegesPanel(privilegesPanel);
        privilegesPanel.revalidate();
        privilegesPanel.repaint();
    }
}
