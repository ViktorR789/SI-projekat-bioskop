package org.example;

public class Projection {
    private int projekcija_id;
    private String naziv;
    private int salaId;
    private String termin;
    private String datum;
    private int slobodnaMesta;

    public Projection(int projekcijaId,String naziv, int salaId, String termin, String datum, int slobodnaMesta) {
        this.projekcija_id=projekcijaId;
        this.naziv = naziv;
        this.salaId = salaId;
        this.termin = termin;
        this.datum = datum;
        this.slobodnaMesta = slobodnaMesta;
    }
    public String getNaziv() {
        return naziv;
    }
    public int getSalaId() {
        return salaId;
    }
    public String getTermin() {
        return termin;
    }
    public String getDatum() {
        return datum;
    }
    public int getSlobodnaMesta() {
        return slobodnaMesta;
    }
    public int getProjekcija_id() {
        return projekcija_id;
    }
    public void setSlobodnaMesta(int slobodnaMesta) {
        this.slobodnaMesta = slobodnaMesta;
    }
    public String toString(){
        return this.getNaziv()+". Datum i termin "+this.getDatum()+" "+this.getTermin()+". "+"Sala "+this.getSalaId();
    }
}
