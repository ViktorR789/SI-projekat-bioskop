package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class User {
    database conn=new database();

    private int userId;
    private String username;
    private String password;

    private JFrame userFrame = new JFrame();
    private CardLayout cardLayout = new CardLayout();
    private JPanel panelContainer = new JPanel(cardLayout);
    private JPanel reservationPanel=new JPanel();

    public User(int userId,String username){
        this.userId=userId;
        this.username=username;
    }

    public int getUserId(){
        return this.userId;
    }

    public String getUsername(){
        return this.username;
    }

    public User(int userId, String username, String password) {
        this.userId = userId;
        this.username = username;
        this.password = password;


        JPanel welcomePanel = new JPanel();
        JPanel menuPanel = new JPanel();
        JPanel settingsPanel = new JPanel();
        JPanel projectionPanel = new JPanel();

        JLabel welcomeLabel = new JLabel();
        welcomePanel.setLayout(new BorderLayout());
        welcomeLabel.setHorizontalAlignment(JLabel.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomeLabel.setText("Dobrodosli "+ this.username);
        welcomePanel.add(welcomeLabel, BorderLayout.CENTER);


        JLabel usernameM=new JLabel();
        JButton projectionsButton = new JButton("Projekcije");
        JButton settingsButton = new JButton("Podesavanja");
        JButton logoutButton = new JButton("Odjava");
        menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));
        menuPanel.setPreferredSize(new Dimension(200, userFrame.getHeight()));
        usernameM.setAlignmentX(Component.CENTER_ALIGNMENT);
        projectionsButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        settingsButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoutButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        usernameM.setPreferredSize(new Dimension(180, 50));
        projectionsButton.setPreferredSize(new Dimension(180, 50));
        settingsButton.setPreferredSize(new Dimension(180, 50));
        logoutButton.setPreferredSize(new Dimension(180, 50));


        projectionsButton.setFocusable(false);
        settingsButton.setFocusable(false);
        logoutButton.addActionListener(e -> logout());


        menuPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        menuPanel.add(usernameM);
        menuPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        menuPanel.add(projectionsButton);
        menuPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        menuPanel.add(settingsButton);
        menuPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        menuPanel.add(logoutButton);

        projectionsButton.addActionListener(e->{
            cardLayout.show(panelContainer, "Movies");
        });
        settingsButton.addActionListener(e->{
            cardLayout.show(panelContainer, "Settings");
        });

        setupProjectionsPanel(projectionPanel);
        setupSettingsPanel(settingsPanel);

        //setupReservationsPanel();


        panelContainer.add(welcomePanel, "Welcome");
        panelContainer.add(projectionPanel, "Movies");
        panelContainer.add(reservationPanel,"Reservations");
        panelContainer.add(settingsPanel, "Settings");

        userFrame.setLayout(new BorderLayout());
        userFrame.add(menuPanel, BorderLayout.WEST);
        userFrame.add(panelContainer, BorderLayout.CENTER);
        userFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        userFrame.setSize(850, 500);
        userFrame.setLocationRelativeTo(null); // Center the frame
        userFrame.setVisible(true);

        cardLayout.show(panelContainer, "Welcome");
    }

    private void logout() {

        this.password=null;
        this.username=null;
        this.username=null;
        userFrame.dispose();

    }

    public void setupProjectionsPanel(JPanel projectionPanel) {

        projectionPanel.setLayout(new BorderLayout());
        List<Projection> projections=conn.getAllProjections();
        JLabel projectionLabel = new JLabel("Projekcije");
        projectionLabel.setHorizontalAlignment(JLabel.CENTER);
        projectionLabel.setFont(new Font("Arial", Font.BOLD, 24));
        projectionPanel.add(projectionLabel, BorderLayout.NORTH);
        JPanel projectionListPanel = new JPanel();
        projectionListPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        for (Projection projection : projections) {
            JPanel singleProjectionPanel = new JPanel();
            singleProjectionPanel.setLayout(new BorderLayout());
            JLabel projectionNameLabel = new JLabel(projection.getNaziv()+" Sala: "+projection.getSalaId()+" "+projection.getTermin()+" Broj karata: "+projection.getSlobodnaMesta());
            projectionNameLabel.setFont(new Font("Arial", Font.PLAIN, 18));
            projectionNameLabel.setPreferredSize(new Dimension(400, 50));
            JButton reserveButton = new JButton("Rezervisi kartu");
            reserveButton.setFocusable(false);
            reserveButton.setPreferredSize(new Dimension(150, 50));
            reserveButton.addActionListener(e -> reserveTicket(projection,projectionPanel));
            singleProjectionPanel.add(projectionNameLabel, BorderLayout.WEST);
            singleProjectionPanel.add(reserveButton, BorderLayout.EAST);
            singleProjectionPanel.setPreferredSize(new Dimension(500, 50));
            projectionListPanel.add(singleProjectionPanel, gbc);
            gbc.gridy++;
            gbc.insets = new Insets(10, 0, 10, 0);
        }
        JScrollPane scrollPane = new JScrollPane(projectionListPanel);
        projectionPanel.add(scrollPane, BorderLayout.CENTER);
    }

    public void setupReservationPanel(Projection projection,JPanel projectionPanel) {
        reservationPanel.removeAll();
        reservationPanel.setLayout(new GridBagLayout());
        JLabel reservationsLabel = new JLabel("Rezervacije");
        reservationsLabel.setHorizontalAlignment(JLabel.CENTER);
        reservationsLabel.setFont(new Font("Arial", Font.BOLD, 24));

        JLabel titleLabel = new JLabel(projection.getNaziv() + " Sala: " + projection.getSalaId() + " Termin: " + projection.getTermin() + " Datum: " + projection.getDatum());
        int slobodna_mesta=projection.getSlobodnaMesta();
        JLabel freeSeatsLabel = new JLabel("Broj slobodnih karata: " + slobodna_mesta);
        JLabel numberOfSeatsLabel = new JLabel("Unesite broj karata: ");
        JTextField numberOfSeatsField = new JTextField(2);
        JButton addReservationButton = new JButton("Prijavite rezervaciju");
        addReservationButton.addActionListener(e -> {
            String enteredSeats = numberOfSeatsField.getText().trim();
            if (enteredSeats.isEmpty()) {
                JOptionPane.showMessageDialog(userFrame, "Molimo unesite broj karata.", "Greska", JOptionPane.ERROR_MESSAGE);
                return;
            }
            int seats=0;
            try {
                seats = Integer.parseInt(enteredSeats);

                if (seats <= 0) {
                    throw new NumberFormatException();
                }
            } catch (NumberFormatException e1) {
                JOptionPane.showMessageDialog(userFrame, "Pogresan format unosa(uneti cifre).", "Greska", JOptionPane.ERROR_MESSAGE);
                return;
            }
            int projectionId=projection.getProjekcija_id();
            int havePrivilege=conn.checkPrivileges(this.userId);
            if(havePrivilege==1){
                if(slobodna_mesta>seats) {
                    String movieTitle = projection.getNaziv();
                    int movieId = conn.getMovieIdByTitle(movieTitle);
                    conn.addNewReservation(projectionId, movieId, this.userId, seats);
                    int newFreeSeats = slobodna_mesta - seats;
                    conn.changeNumberOfFreeSeats(projectionId, newFreeSeats);
                    JOptionPane.showMessageDialog(userFrame, "Rezervacija uspesna.", "Informacija", JOptionPane.INFORMATION_MESSAGE);
                    projection.setSlobodnaMesta(newFreeSeats);
                    refreshReservationPanel(projection, projectionPanel);
                    refreshProjectionPanel(projectionPanel);
                    String userEmail = conn.getUserEmail(this.userId);
                    SendEmail.sendEmail(userEmail, seats, projection);
                }
                else{
                    JOptionPane.showMessageDialog(userFrame, "Nemamo toliko karata. Broj karata je "+slobodna_mesta, "Informacija", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            else {
                int currentReservedSeats = conn.getNumOfTicketsOfProjectionToUser(projectionId, this.userId);
                if (currentReservedSeats == -1) {
                    currentReservedSeats = 0;
                }
                int remainedCards;
                if (10 - currentReservedSeats >= 0) {
                    remainedCards = 10 - currentReservedSeats;
                } else {
                    remainedCards = 0;
                }

                if (seats + currentReservedSeats > 10 || seats > 10) {
                    JOptionPane.showMessageDialog(userFrame, "Mozete maksimalno uzeti 10 karata." + "(Dozvoljeno Vam je jos " + remainedCards + " karata.)", "Greska", JOptionPane.ERROR_MESSAGE);
                } else if (seats > slobodna_mesta) {
                    JOptionPane.showMessageDialog(userFrame, "Dostupan broj karata je " + slobodna_mesta + ".", "Greska", JOptionPane.ERROR_MESSAGE);
                } else {
                    String movieTitle = projection.getNaziv();
                    int movieId = conn.getMovieIdByTitle(movieTitle);
                    conn.addNewReservation(projectionId, movieId, this.userId, seats);
                    int newFreeSeats = slobodna_mesta - seats;
                    conn.changeNumberOfFreeSeats(projectionId, newFreeSeats);
                    JOptionPane.showMessageDialog(userFrame, "Rezervacija uspesna.", "Informacija", JOptionPane.INFORMATION_MESSAGE);
                    projection.setSlobodnaMesta(newFreeSeats);
                    refreshReservationPanel(projection, projectionPanel);
                    refreshProjectionPanel(projectionPanel);
                    String userEmail = conn.getUserEmail(this.userId);
                    SendEmail.sendEmail(userEmail, seats, projection);
                }
            }
        });
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.NORTH;
        gbc.weighty = 0.0;
        reservationPanel.add(reservationsLabel, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(0, 10, 10, 10);
        reservationPanel.add(titleLabel, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.WEST;
        reservationPanel.add(freeSeatsLabel, gbc);
        gbc.gridx = 0;
        gbc.gridy = 3;
        reservationPanel.add(numberOfSeatsLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy=4;
        reservationPanel.add(numberOfSeatsField, gbc);
        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.anchor = GridBagConstraints.CENTER;
        reservationPanel.add(addReservationButton, gbc);
    }


    private void reserveTicket(Projection projection,JPanel projectionPanel) {
        Projection selectedProjection = projection;
        setupReservationPanel(selectedProjection,projectionPanel);
        cardLayout.show(panelContainer, "Reservations");
    }

    public void setupSettingsPanel(JPanel settingsPanel){
        JLabel newUsernameLabel=new JLabel("Novo korisnicko ime:");
        JLabel newPasswordLabel=new JLabel("Nova lozika: ");
        JLabel newPasswordAgainLabel=new JLabel("Ponovite novu lozinku: ");
        JTextField newUsernameField=new JTextField();
        JPasswordField newPasswordField=new JPasswordField();
        JPasswordField newPasswordFieldAgain=new JPasswordField();
        JButton updateButton=new JButton("Promeni");
        settingsPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel settingsLabel = new JLabel("Podesavanja");
        settingsLabel.setHorizontalAlignment(JLabel.CENTER);
        settingsLabel.setFont(new Font("Arial", Font.BOLD, 24));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        settingsPanel.add(settingsLabel, gbc);

        gbc.anchor = GridBagConstraints.WEST;
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        settingsPanel.add(newUsernameLabel, gbc);
        gbc.gridx = 1;
        settingsPanel.add(newUsernameField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        settingsPanel.add(newPasswordLabel, gbc);
        gbc.gridx = 1;
        settingsPanel.add(newPasswordField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 3;
        settingsPanel.add(newPasswordAgainLabel, gbc);
        gbc.gridx = 1;
        settingsPanel.add(newPasswordFieldAgain, gbc);
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.CENTER;
        settingsPanel.add(updateButton, gbc);
        updateButton.addActionListener(e->{
            String newUsername=newUsernameField.getText();
            String newPassword=newPasswordField.getText();
            String newPasswordAgain=newPasswordFieldAgain.getText();
            if(newPasswordAgain.equals(newPasswordAgain)){
                conn.updateUser(this.username,this.password,newUsername,newPassword);
                newUsernameField.setText("");
                newPasswordField.setText("");
                newPasswordFieldAgain.setText("");
            }
        });
    }

    public void refreshReservationPanel(Projection projection,JPanel projectionPanel){
        reservationPanel.removeAll();
        setupReservationPanel(projection,projectionPanel);
        reservationPanel.revalidate();
        reservationPanel.repaint();
    }

    public void refreshProjectionPanel(JPanel projectionPanel){
        projectionPanel.removeAll();
        setupProjectionsPanel(projectionPanel);
        projectionPanel.revalidate();
        reservationPanel.repaint();
    }

}
