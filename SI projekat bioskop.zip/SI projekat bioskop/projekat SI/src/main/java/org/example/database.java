package org.example;


import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class database {
    private String url = "jdbc:mysql://localhost:3306/bioskop";
    private String username = "rootSI";
    private String password = "bioskop1234";


    public String userRegistrated(String username,String password) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "select count(*) from korisnik where username = ? and password=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            ResultSet resultSet = preparedStatement.executeQuery();

            resultSet.next();
            int count = resultSet.getInt(1);
            connection.close();
            return count==1 ? "da" : "ne";
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }

    public int userMode(String username,String password) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "select stanje from korisnik where username=? and password=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            ResultSet resultSet = preparedStatement.executeQuery();

            resultSet.next();
            int stanje = resultSet.getInt(1);
            connection.close();

            return stanje;
        } catch (Exception e) {
            System.out.println(e);
            return -1;
        }
    }

    public int getUserId(String username,String password) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "select korisnik_id from korisnik where username=? and password=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            ResultSet resultSet = preparedStatement.executeQuery();

            resultSet.next();
            int id = resultSet.getInt(1);
            connection.close();

            return id;
        } catch (Exception e) {
            System.out.println(e);
            return -1;
        }
    }


    public int registerUser(String email, String username, String password,String firstName,String lastName) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "insert into korisnik (email, username, password, stanje,ime,prezime) values ( ?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, email);
            preparedStatement.setString(2, username);
            preparedStatement.setString(3, password);
            preparedStatement.setInt(4, 0);
            preparedStatement.setString(5, firstName);
            preparedStatement.setString(6, lastName);
            preparedStatement.executeUpdate();
            connection.close();
            return 1;
        } catch (Exception e) {
            System.out.println(e);
            return 0;
        }
    }

    public int checkEmail(String email) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "select count(*) from korisnik where email = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, email);
            ResultSet resultSet = preparedStatement.executeQuery();

            resultSet.next();
            int count = resultSet.getInt(1);
            connection.close();

            return count == 0 ? 1 : 0;
        } catch (Exception e) {
            System.out.println("Izuzetak: " + e);
            return -1;
        }
    }

    public int checkUsername(String username) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "select count(*) from korisnik where username = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();

            resultSet.next();
            int count = resultSet.getInt(1);
            connection.close();

            return count == 0 ? 1 : 0;
        } catch (Exception e) {
            System.out.println("Greska: " + e.getMessage());
            return -1;
        }
    }

    public int checkPassword(String password) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "select count(*) from korisnik where password = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, password);
            ResultSet resultSet = preparedStatement.executeQuery();

            resultSet.next();
            int count = resultSet.getInt(1);
            connection.close();

            return count == 0 ? 1 : 0;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return -1;
        }
    }



    public void updateUser(String username, String password, String newUsername, String newPassword) {
        String hashNewPassword = LoginPage.hashPassword(newPassword);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "update korisnik set username = ?, password = ? where username = ? AND password = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, newUsername);
            preparedStatement.setString(2, hashNewPassword);
            preparedStatement.setString(3, username);
            preparedStatement.setString(4, password);
            preparedStatement.executeUpdate();
            connection.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<String> getAllMovies() {
        List<String> movies = new ArrayList<>();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "select naziv from film";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                movies.add(resultSet.getString("naziv"));
            }

            connection.close();
        } catch (Exception e) {
            System.out.println( e);
        }
        return movies;
    }

    public void deleteMovie(String title) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "delete from film where naziv=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, title);
            preparedStatement.executeUpdate();
            connection.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void addNewMovie(String movie,int duration) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "insert into film (naziv,trajanje) values (?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, movie);
            preparedStatement.setInt(2, duration);
            preparedStatement.executeUpdate();
            connection.close();
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public int getMovieIdByTitle(String movieName){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "select film_id from film where naziv = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, movieName);
            ResultSet resultSet = preparedStatement.executeQuery();

            resultSet.next();
            int id = resultSet.getInt(1);
            connection.close();

            return id;
        } catch (Exception e) {
            System.out.println(e);
            return -1;
        }
    }

    public void addNewProjection(int hallId, int movieId, int freeSeats, LocalTime termin, LocalDate date) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "insert into projekcija (sala_id, film_id, slobodna_mesta, termin, datum) values (?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, hallId);
            preparedStatement.setInt(2, movieId);
            preparedStatement.setInt(3, freeSeats);
            preparedStatement.setObject(4, termin);
            preparedStatement.setObject(5, date);
            preparedStatement.executeUpdate();
            connection.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public int getNumOfHalls(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "select count(sala_id) from bioskopska_sala";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            resultSet.next();
            int count = resultSet.getInt(1);
            connection.close();
            System.out.println(count);
            return count;
        } catch (Exception e) {
            System.out.println(e);
            return -1;
        }
    }

    public int movieExists(String movieTitle){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "select count(film_id) from film where naziv=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, movieTitle);
            ResultSet resultSet = preparedStatement.executeQuery();

            resultSet.next();
            int count = resultSet.getInt(1);
            connection.close();
            return count==1 ? 1 : 0;
        } catch (Exception e) {
            System.out.println(e);
            return -1;
        }
    }

    public void deleteProjectionsForMovie(int movieId) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "delete from projekcija where film_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, movieId);
            preparedStatement.executeUpdate();
            connection.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Projection> getAllProjections() {
        List<Projection> projections = new ArrayList<>();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "select p.projekcija_id,f.naziv, p.sala_id, p.termin, p.datum, p.slobodna_mesta from film f join projekcija p on f.film_id = p.film_id";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int projekcijaId = resultSet.getInt("p.projekcija_id");
                String naziv = resultSet.getString("f.naziv");
                int salaId = resultSet.getInt("p.sala_id");
                String termin = resultSet.getString("p.termin");
                String datum = resultSet.getString("p.datum");
                int slobodnaMesta = resultSet.getInt("p.slobodna_mesta");
                projections.add(new Projection(projekcijaId,naziv, salaId, termin, datum, slobodnaMesta));
            }

            connection.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return projections;
    }

    public void addNewReservation(int projectionId,int movieId,int userId,int numberOfSeats){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "insert into rezervacije(projekcija_id,film_id,korisnik_id,broj_karata) values (?,?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, projectionId);
            preparedStatement.setInt(2, movieId);
            preparedStatement.setInt(3, userId);
            preparedStatement.setInt(4, numberOfSeats);
            preparedStatement.executeUpdate();
            connection.close();

        } catch (Exception e) {
            System.out.println(e);
        }

    }

    public int getNumOfTicketsOfProjectionToUser(int projectionId,int userId){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "select sum(broj_karata) from rezervacije where projekcija_id=? and korisnik_id=? group by projekcija_id,korisnik_id";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, projectionId);
            preparedStatement.setInt(2, userId);
            ResultSet resultSet = preparedStatement.executeQuery();

            resultSet.next();
            int count = resultSet.getInt(1);
            connection.close();
            return count;

        }catch (Exception e) {
            System.out.println("Nema u bazi.");
            return -1;
        }
    }

    public void deleteReservationForMovie(int movieId) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "delete from rezervacije where film_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, movieId);
            preparedStatement.executeUpdate();
            connection.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public String getUserEmail(int userId){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "select email from korisnik where korisnik_id=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();
            resultSet.next();
            String email = resultSet.getString(1);
            connection.close();
            System.out.println(email);
            return email;
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }


    public void changeNumberOfFreeSeats(int projectionId,int newNumber){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "update projekcija set slobodna_mesta=? where projekcija_id=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, newNumber);
            preparedStatement.setInt(2, projectionId);
            preparedStatement.executeUpdate();
            connection.close();

        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public int getNumberOfSeatsOfHall(int hallId){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "select kapacitet from bioskopska_sala where sala_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, hallId);
            ResultSet resultSet = preparedStatement.executeQuery();

            resultSet.next();
            int capacity = resultSet.getInt(1);
            connection.close();

            return capacity;
        } catch (Exception e) {
            System.out.println(e);
            return -1;
        }
    }

    public void deleteProjectionsStartedBeforeNow() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            LocalTime currentTime = LocalTime.now();
            LocalDate currentDate = LocalDate.now();

            String deleteReservationsQuery = "delete from rezervacije where projekcija_id in " +
                    "(select projekcija_id from projekcija " +
                    "where datum < ? or (datum = ? and termin < ?))";
            PreparedStatement deleteReservationsStmt = connection.prepareStatement(deleteReservationsQuery);
            deleteReservationsStmt.setDate(1, java.sql.Date.valueOf(currentDate));
            deleteReservationsStmt.setDate(2, java.sql.Date.valueOf(currentDate));
            deleteReservationsStmt.setTime(3, Time.valueOf(currentTime));
            deleteReservationsStmt.executeUpdate();

            String deleteProjectionsQuery = "delete from projekcija where datum < ? or (datum = ? and termin < ?)";
            PreparedStatement deleteProjectionsStmt = connection.prepareStatement(deleteProjectionsQuery);
            deleteProjectionsStmt.setDate(1, java.sql.Date.valueOf(currentDate));
            deleteProjectionsStmt.setDate(2, java.sql.Date.valueOf(currentDate));
            deleteProjectionsStmt.setTime(3, Time.valueOf(currentTime));
            deleteProjectionsStmt.executeUpdate();

            connection.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<User> listUsersWithoutPrivileges(){
        List<User> users = new ArrayList<>();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "select k.korisnik_id,k.username from korisnik k where k.stanje=0 and k.korisnik_id not in (select p.korisnik_id from privilegovani_korisnici p)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int userId = resultSet.getInt("k.korisnik_id");
                String username = resultSet.getString("k.username");
                users.add(new User(userId,username));
            }

            connection.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return users;
    }

    public void addPrivilegesToUser(int userId){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "insert into privilegovani_korisnici(korisnik_id,privilegija) values (?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userId);
            preparedStatement.setInt(2, 1);
            preparedStatement.executeUpdate();
            connection.close();

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public int checkPrivileges(int userId){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, this.username, this.password);
            String query = "select privilegija from privilegovani_korisnici where korisnik_id=? ";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();

            resultSet.next();
            int privilege = resultSet.getInt(1);
            connection.close();

            return privilege;
        } catch (Exception e) {
            return -1;
        }
    }
}
