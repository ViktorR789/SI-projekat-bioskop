package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Pattern;

public class LoginPage  {
    database conn=new database();


    LoginPage() {
        conn.deleteProjectionsStartedBeforeNow();
        JFrame frame = new JFrame();
        CardLayout cardLayout = new CardLayout();
        JPanel panelContainer = new JPanel(cardLayout);
        JPanel loginPanel = new JPanel(null);
        JPanel registerPanel = new JPanel(null);


        JLabel loginTitle=new JLabel("Prijavite se ili registujte svoj nalog.");
        JButton loginButton = new JButton("Login");
        JButton resetButton = new JButton("Reset");
        JButton createAccButton = new JButton("Napravite nalog");
        JTextField usernameField = new JTextField();
        JPasswordField userPasswordField = new JPasswordField();
        JLabel usernameLabel = new JLabel("Korisnicko ime:");
        JLabel userPasswordLabel = new JLabel("Lozinka:");
        JLabel messageLabel = new JLabel();
        JLabel notRegistered=new JLabel("Niste registrovani?");
        JLabel messageLoginLabel=new JLabel();


        JLabel registerTitle=new JLabel("Registracija");
        JButton registerButton = new JButton("Register");
        JButton backButton = new JButton("Nazad");
        JTextField registerFirstNameField=new JTextField();
        JTextField registerLastNameField=new JTextField();
        JTextField registerUsernameField = new JTextField();
        JPasswordField registerUserPasswordField = new JPasswordField();
        JPasswordField registerUserPasswordAgainField=new JPasswordField();
        JTextField registerEmailField = new JTextField();
        JLabel registerFirstNameLabel=new JLabel("Vase ime: ");
        JLabel registerLastNameLabel=new JLabel("Vase prezime: ");
        JLabel registerUsernameLabel = new JLabel("Korisnicko ime:");
        JLabel registerUserPasswordLabel = new JLabel("Lozinka:");
        JLabel registerUserPasswordAgainLabel=new JLabel("Ponovite lozinku: ");
        JLabel registerEmailLabel = new JLabel("E-mail adresa:");
        JLabel registerMessageLabel = new JLabel();


        loginTitle.setBounds(75,50,200,25);
        usernameLabel.setBounds(50, 100, 150, 25);
        userPasswordLabel.setBounds(50, 150, 75, 25);
        messageLoginLabel.setBounds(70, 300, 400, 35);
        messageLoginLabel.setFont(new Font(null, Font.ITALIC, 25));
        usernameField.setBounds(175, 100, 200, 25);
        userPasswordField.setBounds(175, 150, 200, 25);
        loginButton.setBounds(125, 200, 100, 25);
        loginButton.setFocusable(false);

        resetButton.setBounds(225, 200, 100, 25);
        resetButton.setFocusable(false);
        notRegistered.setBounds(50,250,150,25);
        createAccButton.setBounds(200, 250, 200, 25);
        createAccButton.setFocusable(false);

        loginPanel.add(loginTitle);
        loginPanel.add(usernameLabel);
        loginPanel.add(userPasswordLabel);
        loginPanel.add(messageLoginLabel);
        loginPanel.add(usernameField);
        loginPanel.add(userPasswordField);
        loginPanel.add(loginButton);
        loginPanel.add(resetButton);
        loginPanel.add(notRegistered);
        loginPanel.add(createAccButton);

        resetButton.addActionListener(e -> {
            usernameField.setText("");
            userPasswordField.setText("");
        });

        loginButton.addActionListener(e->{
            String username = usernameField.getText();
            String password = String.valueOf(userPasswordField.getPassword());
            if(username.isEmpty() || password.isEmpty()){
                messageLoginLabel.setForeground(Color.red);
                messageLoginLabel.setText("Napisite korisnicko ime i lozinku.");
            }
            else{
                password=hashPassword(password);
                String userExist=conn.userRegistrated(username,password);
                if(userExist=="da"){
                    int mode=conn.userMode(username,password);
                    if(mode==0){
                        messageLoginLabel.setForeground(Color.red);
                        messageLoginLabel.setText("Korisnik.");
                        int userID=conn.getUserId(username,password);
                        User user=new User(userID,username,password);
                        frame.dispose();

                    }
                    else if(mode==1){
                        messageLoginLabel.setForeground(Color.red);
                        messageLoginLabel.setText("Zaposleni.");
                        int userID=conn.getUserId(username,password);
                        Employee employee =new Employee(userID,username,password);
                        frame.dispose();
                    }
                }
                else{
                    messageLoginLabel.setForeground(Color.red);
                    messageLoginLabel.setText("Korisnik ne postoji.");
                }
            }
        });

        createAccButton.addActionListener(e->{
            cardLayout.show(panelContainer, "register");
        });


        registerTitle.setBounds(50,20,120,25);
        registerFirstNameLabel.setBounds(50,70,150,25);
        registerLastNameLabel.setBounds(50,120,150,25);
        registerUsernameLabel.setBounds(50, 170, 150, 25);
        registerUserPasswordLabel.setBounds(50, 220, 75, 25);
        registerUserPasswordAgainLabel.setBounds(50,270,120,25);
        registerEmailLabel.setBounds(50, 320, 120, 25);
        registerMessageLabel.setBounds(125, 370, 250, 35);
        registerMessageLabel.setFont(new Font(null, Font.ITALIC, 25));
        registerFirstNameField.setBounds(200,70,150,25);
        registerLastNameField.setBounds(200,120,150,25);
        registerUsernameField.setBounds(200, 170, 200, 25);
        registerUserPasswordField.setBounds(200, 220, 200, 25);
        registerUserPasswordAgainField.setBounds(200,270,200,25);
        registerEmailField.setBounds(200, 320, 200, 25);
        registerButton.setBounds(125, 390, 100, 25);
        registerButton.setFocusable(false);
        backButton.setBounds(225, 390, 100, 25);
        backButton.setFocusable(false);
        messageLabel.setBounds(125,420,400,35);
        messageLabel.setFont(new Font(null,Font.ITALIC,25));

        registerPanel.add(registerTitle);
        registerPanel.add(registerFirstNameLabel);
        registerPanel.add(registerLastNameLabel);
        registerPanel.add(registerUsernameLabel);
        registerPanel.add(registerUserPasswordLabel);
        registerPanel.add(registerUserPasswordAgainLabel);
        registerPanel.add(registerEmailLabel);
        registerPanel.add(registerMessageLabel);
        registerPanel.add(registerFirstNameField);
        registerPanel.add(registerLastNameField);
        registerPanel.add(registerUsernameField);
        registerPanel.add(registerUserPasswordField);
        registerPanel.add(registerUserPasswordAgainField);
        registerPanel.add(registerEmailField);
        registerPanel.add(registerButton);
        registerPanel.add(backButton);
        registerPanel.add(messageLabel);

        registerButton.addActionListener(e->{
            String firstName = registerFirstNameField.getText();
            String lastName = registerLastNameField.getText();
            String username = registerUsernameField.getText();
            String password = String.valueOf(registerUserPasswordField.getPassword());
            String passwordAgain=String.valueOf(registerUserPasswordAgainField.getPassword());
            String email = registerEmailField.getText();
            if(email.isEmpty() || username.isEmpty() || password.isEmpty() || firstName.isEmpty() || lastName.isEmpty()){
                messageLabel.setForeground(Color.red);
                messageLabel.setText("Popunite sva polja.");
            }
            else {
                if (passwordAgain.equals(password)) {
                    int flagEmail = conn.checkEmail(email);
                    if (flagEmail == 1) {
                        if(isValidEmail(email)) {
                            int flagUsername = conn.checkUsername(username);
                            if (flagUsername == 1) {
                                password=hashPassword(password);
                                int flagPassword = conn.checkPassword(password);
                                if (flagPassword == 1) {
                                    int flag = conn.registerUser(email, username, password,firstName,lastName);
                                    if (flag == 1) {
                                        messageLabel.setForeground(Color.green);
                                        messageLabel.setText("Uspesna registracija");
                                        registerUsernameField.setText("");
                                        registerUserPasswordField.setText("");
                                        registerUserPasswordAgainField.setText("");
                                        registerEmailField.setText("");
                                        registerFirstNameField.setText("");
                                        registerLastNameField.setText("");
                                    } else {
                                        messageLabel.setForeground(Color.red);
                                        messageLabel.setText("Registracija nije uspela");
                                    }
                                } else {
                                    messageLabel.setForeground(Color.red);
                                    messageLabel.setText("Sifra je zauzeta");
                                }
                            } else {
                                messageLabel.setForeground(Color.red);
                                messageLabel.setText("Korisnicko ime je zauzeto");
                            }
                        }else{
                            messageLabel.setForeground(Color.red);
                            messageLabel.setText("Email adresa nije u tacnom formatu.");
                        }
                    } else {
                        messageLabel.setForeground(Color.red);
                        messageLabel.setText("Email adresa je zauzeta");
                    }
                } else {
                    messageLabel.setForeground(Color.red);
                    messageLabel.setText("Unete sifre se razlikuju");
                }
            }
        });

        backButton.addActionListener(e->{
            cardLayout.show(panelContainer, "login");
        });



        panelContainer.add(loginPanel, "login");
        panelContainer.add(registerPanel, "register");

        frame.add(panelContainer);
        cardLayout.show(panelContainer, "login");

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 700);
        frame.setVisible(true);
    }

    public boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        if (email == null)
            return false;
        return pattern.matcher(email).matches();
    }

    public static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedPassword = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashedPassword) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }


}
