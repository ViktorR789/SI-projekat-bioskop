create database bioskop;

use bioskop;

create table korisnik(
korisnik_id int auto_increment,
email char(50),
username char(50),
password char(100),
stanje int,
ime char(50),
prezime char(128),
primary key(korisnik_id));

create table film(
film_id int auto_increment,
naziv varchar(50),
trajanje int,
primary key (film_id));


create table bioskopska_sala(
sala_id int auto_increment,
kapacitet int,
primary key(sala_id));

create table projekcija(
	projekcija_id int auto_increment,
    sala_id int,
    film_id int,
    slobodna_mesta int,
    termin time,
    datum date,
    primary key(projekcija_id),
    foreign key(sala_id) references bioskopska_sala(sala_id),
    foreign key(film_id) references film(film_id)
);


create table rezervacije(
	rezervacija_id int auto_increment,
    projekcija_id int,
    film_id int,
    korisnik_id int,
    broj_karata int,
    primary key(rezervacija_id),
    foreign key(projekcija_id) references projekcija(projekcija_id),
    foreign key(film_id) references projekcija(film_id),
    foreign key(korisnik_id) references korisnik(korisnik_id)
);


create table privilegovani_korisnici(
	korisnik_id int,
    privilegija int,
    primary key(korisnik_id),
    foreign key(korisnik_id) references korisnik(korisnik_id));
