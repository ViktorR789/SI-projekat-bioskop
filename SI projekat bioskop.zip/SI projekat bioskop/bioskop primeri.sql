-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 29, 2024 at 02:33 PM
-- Server version: 8.0.36
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bioskop`
--

-- --------------------------------------------------------

--
-- Table structure for table `bioskopska_sala`
--

DROP TABLE IF EXISTS `bioskopska_sala`;
CREATE TABLE IF NOT EXISTS `bioskopska_sala` (
  `sala_id` int NOT NULL AUTO_INCREMENT,
  `kapacitet` int DEFAULT NULL,
  PRIMARY KEY (`sala_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `bioskopska_sala`
--

INSERT INTO `bioskopska_sala` (`sala_id`, `kapacitet`) VALUES
(1, 100),
(2, 110),
(3, 120),
(4, 90),
(5, 85);

-- --------------------------------------------------------

--
-- Table structure for table `film`
--

DROP TABLE IF EXISTS `film`;
CREATE TABLE IF NOT EXISTS `film` (
  `film_id` int NOT NULL AUTO_INCREMENT,
  `naziv` varchar(50) DEFAULT NULL,
  `trajanje` int DEFAULT NULL,
  PRIMARY KEY (`film_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `film`
--

INSERT INTO `film` (`film_id`, `naziv`, `trajanje`) VALUES
(10, 'Mesec', 213),
(13, 'Betmen', 90),
(14, 'Supermen', 95),
(15, 'Spajdermen', 110),
(16, 'Betmen 2', 125),
(17, 'Avatar', 145),
(18, 'ET', 85);

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

DROP TABLE IF EXISTS `korisnik`;
CREATE TABLE IF NOT EXISTS `korisnik` (
  `korisnik_id` int NOT NULL AUTO_INCREMENT,
  `email` char(50) DEFAULT NULL,
  `username` char(50) DEFAULT NULL,
  `password` char(100) DEFAULT NULL,
  `stanje` int DEFAULT NULL,
  `ime` char(50) DEFAULT NULL,
  `prezime` char(128) DEFAULT NULL,
  PRIMARY KEY (`korisnik_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`korisnik_id`, `email`, `username`, `password`, `stanje`, `ime`, `prezime`) VALUES
(1, 'marko1@gmail.com', 'marko1', 'f18d6b99c2220efb480af983c37ddd65ba0262fe72b55e3ea67d4288798c1374', 0, 'marko1', 'markovic'),
(2, 'steva1@gmail.com', 'steva1', 'dcacc784115e4ba842a7b53d83abffbcf20744a76de22206171946bb583eddd4', 1, 'steva1', 'steva1'),
(3, 'viktorradosavljevic13@gmail.com', 'viktor2', '8157269f73d1ee4a27d72725172d8ba3fbfe42f2b7b412bbdb777fae14e582f9', 0, 'viktor', 'radosavljevic'),
(10, 'mikica1@gmail.com', 'mikica1', 'b2907b0936f3e3171a4aec746a5d7b25b1c2f0d80c3f81ad95a045f005f185d2', 0, 'mikica', 'mikicic');

-- --------------------------------------------------------

--
-- Table structure for table `privilegovani_korisnici`
--

DROP TABLE IF EXISTS `privilegovani_korisnici`;
CREATE TABLE IF NOT EXISTS `privilegovani_korisnici` (
  `korisnik_id` int NOT NULL,
  `privilegija` int DEFAULT NULL,
  PRIMARY KEY (`korisnik_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `privilegovani_korisnici`
--

INSERT INTO `privilegovani_korisnici` (`korisnik_id`, `privilegija`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `projekcija`
--

DROP TABLE IF EXISTS `projekcija`;
CREATE TABLE IF NOT EXISTS `projekcija` (
  `projekcija_id` int NOT NULL AUTO_INCREMENT,
  `sala_id` int DEFAULT NULL,
  `film_id` int DEFAULT NULL,
  `slobodna_mesta` int DEFAULT NULL,
  `termin` time DEFAULT NULL,
  `datum` date DEFAULT NULL,
  PRIMARY KEY (`projekcija_id`),
  KEY `sala_id` (`sala_id`),
  KEY `film_id` (`film_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `projekcija`
--

INSERT INTO `projekcija` (`projekcija_id`, `sala_id`, `film_id`, `slobodna_mesta`, `termin`, `datum`) VALUES
(11, 4, 10, 41, '20:00:00', '2025-01-01'),
(13, 1, 13, 53, '21:00:00', '2024-06-30'),
(14, 2, 13, 46, '20:00:00', '2024-06-30');

-- --------------------------------------------------------

--
-- Table structure for table `rezervacije`
--

DROP TABLE IF EXISTS `rezervacije`;
CREATE TABLE IF NOT EXISTS `rezervacije` (
  `rezervacija_id` int NOT NULL AUTO_INCREMENT,
  `projekcija_id` int DEFAULT NULL,
  `film_id` int DEFAULT NULL,
  `korisnik_id` int DEFAULT NULL,
  `broj_karata` int DEFAULT NULL,
  PRIMARY KEY (`rezervacija_id`),
  KEY `projekcija_id` (`projekcija_id`),
  KEY `film_id` (`film_id`),
  KEY `korisnik_id` (`korisnik_id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `rezervacije`
--

INSERT INTO `rezervacije` (`rezervacija_id`, `projekcija_id`, `film_id`, `korisnik_id`, `broj_karata`) VALUES
(69, 13, 13, 3, 10);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `privilegovani_korisnici`
--
ALTER TABLE `privilegovani_korisnici`
  ADD CONSTRAINT `privilegovani_korisnici_ibfk_1` FOREIGN KEY (`korisnik_id`) REFERENCES `korisnik` (`korisnik_id`);

--
-- Constraints for table `projekcija`
--
ALTER TABLE `projekcija`
  ADD CONSTRAINT `projekcija_ibfk_1` FOREIGN KEY (`sala_id`) REFERENCES `bioskopska_sala` (`sala_id`),
  ADD CONSTRAINT `projekcija_ibfk_2` FOREIGN KEY (`film_id`) REFERENCES `film` (`film_id`);

--
-- Constraints for table `rezervacije`
--
ALTER TABLE `rezervacije`
  ADD CONSTRAINT `rezervacije_ibfk_1` FOREIGN KEY (`projekcija_id`) REFERENCES `projekcija` (`projekcija_id`),
  ADD CONSTRAINT `rezervacije_ibfk_2` FOREIGN KEY (`film_id`) REFERENCES `projekcija` (`film_id`),
  ADD CONSTRAINT `rezervacije_ibfk_3` FOREIGN KEY (`korisnik_id`) REFERENCES `korisnik` (`korisnik_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
